// SPDX-FileCopyrightText: 2026 amurcanov
// SPDX-License-Identifier: PolyForm-Noncommercial-1.0.0

//! 64-битные атомики, доступные на всех наших таргетах.
//!
//! На MIPS32 (mt7621: mipsel-unknown-linux-musl, +soft-float) в std нет
//! AtomicI64/AtomicU64 — ядро не даёт 64-битных атомарных инструкций.
//! portable-atomic на таких таргетах автоматически подставляет lock-режим,
//! а на aarch64/x86_64 использует нативные 64-битные инструкции.

#[cfg(not(all(target_arch = "mips", target_pointer_width = "32")))]
pub use std::sync::atomic::{AtomicI64, AtomicU64};

#[cfg(all(target_arch = "mips", target_pointer_width = "32"))]
pub use portable_atomic::{AtomicI64, AtomicU64};

/// Ordering реэкспортируется для удобства миграции импортов: на MIPS32
/// portable-atomic использует собственный тип Ordering, несовместимый
/// по типу с std::sync::atomic::Ordering.
#[cfg(all(target_arch = "mips", target_pointer_width = "32"))]
pub use portable_atomic::Ordering;

#[cfg(not(all(target_arch = "mips", target_pointer_width = "32")))]
pub use std::sync::atomic::Ordering;
